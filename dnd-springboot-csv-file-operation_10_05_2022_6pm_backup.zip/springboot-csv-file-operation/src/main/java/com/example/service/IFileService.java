package com.example.service;

public interface IFileService {

    // read file

    // copy file

    // move file

    // delete file
}
