package com.example.service;

import com.example.config.FileConfigs;
import com.example.constants.IConstants;
import com.example.dto.ItemDto;
import com.example.utils.CSVFileUtils;
import com.example.utils.DateUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class CsvFileBodyValidationService {

    private static final Logger logger = LoggerFactory.getLogger(CsvFileBodyValidationService.class);

    @Autowired
    private FileConfigs fc;

    @Autowired
    private FileService fs;

    @Autowired
    private GenericValidationService genericValidationService;

    Boolean flag;

    // file validation
    public void startFileBodyValidation(List<String> csvHeaderList, List<ItemDto> itemData, String filePath) {
        logger.info("START :::: file validation ::::: {}", logger.getName());

        int lineNo = 1; // track row number for error purpose

        String sfileName = fc.getFileName();
        String slocation = StringUtils.join(fc.getInputFolder(), IConstants.CommonConstants.SLASH);
        filePath = StringUtils.join(slocation, sfileName);


        itemData = fs.getFileContentsAsList();

        // condition -- headers present but file body missing
        validateFileBody(itemData, sfileName);

        csvHeaderList = csvHeaderList.stream().map(String::trim).collect(Collectors.toList());
        logger.info("csv header list ::: {}", csvHeaderList.toString());

        // check validation on file contents
        for(ItemDto model: itemData) {
            lineNo = lineNo + 1; // first row assumed to be header
            performGenericValidations(model, sfileName, lineNo);
        }

        logger.info("END :::: file validation ::::: {}", logger.getName());

    }

    // check file body contents
    private void validateFileBody(List<ItemDto> itemList, String fileName) {
        if (!CollectionUtils.isNotEmpty(itemList)) {
            logger.info("file [{}] is empty, moving it to error folder", fileName);

            String slocation = StringUtils.join(fc.getInputFolder(), IConstants.CommonConstants.SLASH);
            String edlocation = StringUtils.join(fc.getErrorFolder(), IConstants.CommonConstants.SLASH);

            String dfilename = CSVFileUtils.errorFileName(fileName);
            String errmsg = "header is present but file body contents missing";

            fs.moveFileToErrorFolder(slocation, edlocation, fileName, dfilename, errmsg);

            logger.info("file [{}] moved successfully to error folder", fileName);

            System.exit(1);
        }
    }

    // generic validations
    protected void performGenericValidations(ItemDto model, String sfileName, int rowCounter) {

        // check if item id exist
        if(validateItemIdExist(model.getItem_id(), rowCounter) == true) {
            logger.info("item id validation successful; proceed to item name validation...");
            // if yes, check if item name exist
            if(validateItemNameExist(model.getItem_name(), rowCounter) == true) {
                logger.info("item name validated..");
            }
            /*// validate item dates
            if(validateItemMfgExpDates(model.getItem_manufactured_date(),
                    model.getItem_expiry_date(), rowCounter) == true) {
                logger.info("item mfg and item expiry date validated..");
            }*/
        }

        logger.info("All validations are successfull, writing entire file to success folder");

        // moving and writing file to success folder
        String sfilename = fc.getFileName();

        String slocation = StringUtils.join(fc.getInputFolder(), IConstants.CommonConstants.SLASH);
        String sdlocation = StringUtils.join(fc.getSuccessFolder(), IConstants.CommonConstants.SLASH);

        String dfileName = CSVFileUtils.successFileName(sfilename);

        fs.moveFileToSuccessFolder(slocation, sdlocation, sfileName, dfileName);

    }

    // validate if item id is blank
    protected boolean validateItemIdExist(int id, int rowCounter) {
        logger.info("item id. for validation :::: {}", id);

        if(id == 0) {
            logger.info("item id. = {}", id);
            logger.info("item id. is not valid; hence moving file to error folder");

            String sfilename = fc.getFileName();

            String slocation = StringUtils.join(fc.getInputFolder(), IConstants.CommonConstants.SLASH);
            String edlocation = StringUtils.join(fc.getErrorFolder(), IConstants.CommonConstants.SLASH);

            String dfileName = CSVFileUtils.errorFileName(sfilename);

            String errMsg = "item id is missing at line "+rowCounter+". Hence, file moved to error location.";

            fs.moveFileToErrorFolder(slocation, edlocation, sfilename, dfileName, errMsg);
            System.exit(1);
            flag = false;
        }
        else {
            logger.info("item id validation successful");
            flag = true;
        }

        return flag;
    }
    // validate if item name is empty
    protected boolean validateItemNameExist(String itemName, int rowCounter) {
        if(!StringUtils.isNotEmpty(itemName)) {
            logger.info("item name is empty; hence moving file to error folder");

            String sfilename = fc.getFileName();

            String slocation = StringUtils.join(fc.getInputFolder(), IConstants.CommonConstants.SLASH);
            String edlocation = StringUtils.join(fc.getErrorFolder(), IConstants.CommonConstants.SLASH);

            String dfileName = CSVFileUtils.errorFileName(sfilename);

            String errMsg = "Item Name is blank at row "+rowCounter+". Hence, file moved to error location.";

            fs.moveFileToErrorFolder(slocation, edlocation, sfilename, dfileName, errMsg);
            System.exit(1);
            flag = false;
        }
        else {
            logger.info("item name validation successful");
            flag = true;
        }

        return flag;
    }

    /*// validate dates
    protected boolean validateItemMfgExpDates(String itemMfgDate, String itemExpDate, int rowCounter) {

        LocalDate mfgDate = DateUtil.strToDate(itemMfgDate);
        LocalDate expDate = DateUtil.strToDate(itemExpDate);

        logger.debug("Manufacturing date received :- ", mfgDate);

        if(mfgDate.isAfter(LocalDate.now())) {
            logger.info("item mfg date is invalid; hence moving file to error folder");

            String sfilename = fc.getFileName();

            String slocation = StringUtils.join(fc.getInputFolder(), IConstants.CommonConstants.SLASH);
            String edlocation = StringUtils.join(fc.getErrorFolder(), IConstants.CommonConstants.SLASH);

            String dfileName = CSVFileUtils.errorFileName(sfilename);

            String errMsg = "Item Mfg. date at row "+rowCounter+" is greater than current date, which is incorrect. Hence, file moved to error location.";

            fs.moveFileToErrorFolder(slocation, edlocation, sfilename, dfileName, errMsg);
            System.exit(1);
            flag = false;
        }


        *//*if(!StringUtils.isNotEmpty(itemMfgDate)) {
            logger.info("item mfg date is empty; hence moving file to error folder");

            String sfilename = fc.getFileName();

            String slocation = StringUtils.join(fc.getInputFolder(), IConstants.CommonConstants.SLASH);
            String edlocation = StringUtils.join(fc.getErrorFolder(), IConstants.CommonConstants.SLASH);

            String dfileName = CSVFileUtils.errorFileName(sfilename);

            String errMsg = "Item Name is blank at row "+rowCounter+". Hence, file moved to error location.";

            fs.moveFileToErrorFolder(slocation, edlocation, sfilename, dfileName, errMsg);
            System.exit(1);
            flag = false;
        }
        else {
            logger.info("item name validation successful");
            flag = true;
        }*//*

        return flag;
    }*/
}
