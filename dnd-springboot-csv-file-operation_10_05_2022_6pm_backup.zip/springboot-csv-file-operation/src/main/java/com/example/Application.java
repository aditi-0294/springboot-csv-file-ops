package com.example;

import com.example.processor.FileProcessor;
import com.example.service.FileService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(Application.class);

    @Autowired
    private FileProcessor process;

    public static void main(String[] args) {
        System.out.println("Hello world!");
        SpringApplication.run(Application.class,args);
    }

    @Override
    public void run(String... args) throws Exception {
        process.initiateTask();
    }
}