package com.example.processor;

import com.example.config.FileConfigs;
import com.example.constants.IConstants;
import com.example.dto.ItemDto;
import com.example.service.CsvFileBodyValidationService;
import com.example.service.FileService;
import com.example.service.GenericValidationService;
import com.example.utils.CSVFileUtils;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;

@Component
public class FileProcessor {

    private static final Logger logger = LoggerFactory.getLogger(FileProcessor.class);

    @Autowired
    private FileService fs;

    @Autowired
    private GenericValidationService genericValidationService;

    @Autowired
    private CsvFileBodyValidationService csvFileBodyValidationService;

    private String sfileName;
    private String dfileName;
    private String sLocation;
    private String dLocation;
    private String errorMsg;


    public void initiateTask() {
        logger.info("START :::: initiate task :::: {}", logger.getName());
        startValidation(sfileName);
        logger.info("END :::: initiate task :::: {}", logger.getName());
    }

    private void startValidation(String sfileName) {
        logger.info("START :::: start validation process :::: {}", logger.getName());

        // check for csv file extension
        genericValidationService.validateFileExtension(sfileName);

        Map<String, Object> fileData = fs.getHeaderColumnsList(sLocation, sfileName);

        // checks if file is empty; if not returns csv file header as list
        List<String> csvHeaderColumnList = (List<String>) fileData.get("headerData");
        logger.info("Total header count for file = {}", csvHeaderColumnList.size()); // size = 8

        if(MapUtils.isNotEmpty(fileData)) {
           // checkMandatoryColumns(List<String> csvHeaderColumnList);

            // validate csv file
            logger.info("============= starting file body validation =============");
            List<ItemDto> itemData = null;
            //fs.getFileContentsAsList();
            csvFileBodyValidationService.startFileBodyValidation(csvHeaderColumnList, itemData, sfileName);
            logger.info("============= file body validation completed successfully =============");

        }
        else {
            // move file to error folder along with error message
            fs.moveFileToErrorFolder(sfileName, dLocation, sfileName, dfileName, errorMsg);
        }

        logger.info("END :::: end validation process :::: {}", logger.getName());

    }

}
