package com.example.dto;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;
import lombok.Getter;
import lombok.Setter;
import org.springframework.context.annotation.Bean;

import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
public class ItemDto implements Serializable {

    @CsvBindByName(column = "item id")
    @CsvBindByPosition(position = 0)
    private int item_id;

    @CsvBindByName(column = "item name")
    @CsvBindByPosition(position = 1)
    private String item_name;

    @CsvBindByName(column = "item description")
    @CsvBindByPosition(position = 2)
    private String item_description;

    @CsvBindByName(column = "item type")
    @CsvBindByPosition(position = 3)
    private String item_type;

    @CsvBindByName(column = "item price")
    @CsvBindByPosition(position = 4)
    private double item_price;

    @CsvBindByName(column = "item manufactured date")
    @CsvBindByPosition(position = 5)
    private String item_manufactured_date;

    @CsvBindByName(column = "item expiry date")
    @CsvBindByPosition(position = 6)
    private String item_expiry_date;

    @CsvBindByName(column = "item qty")
    @CsvBindByPosition(position = 7)
    private int item_qty;


    public ItemDto()
    {
        // default constructor
    }

    // parameterized constructor
    public ItemDto(int item_id, String item_name, String item_description, String item_type, double item_price, String item_manufactured_date, String item_expiry_date, int item_qty) {
        this.item_id = item_id;
        this.item_name = item_name;
        this.item_description = item_description;
        this.item_type = item_type;
        this.item_price = item_price;
        this.item_manufactured_date = item_manufactured_date;
        this.item_expiry_date = item_expiry_date;
        this.item_qty = item_qty;
    }

    //toString()
    @Override
    public String toString() {
        return "ItemDto{" +
                "item_id=" + item_id +
                ", item_name='" + item_name + '\'' +
                ", item_description='" + item_description + '\'' +
                ", item_type='" + item_type + '\'' +
                ", item_price=" + item_price +
                ", item_manufactured_date='" + item_manufactured_date + '\'' +
                ", item_expiry_date='" + item_expiry_date + '\'' +
                ", item_qty=" + item_qty +
                '}';
    }


}
