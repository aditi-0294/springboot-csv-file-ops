package com.example.constants;

public interface IConstants {

    public final class CommonConstants {
        public static final String SLASH = "/";
        public static final char CSV_DELIMITER = ',';
        public static final String NEW_LINE = "\r\n";
        public static final String CSV_EXTENSION = "csv";
    }

    public final class ExceptionConstants {
        public static final String FILE_READ_EXCEPTION = "Unable to read file {}";
        public static final String FILE_NOT_FOUND = "file {} not found";
        public static final String FILE_EXTENSION_FORMAT_EXCEPTION = "file is in incorrect format... provide proper file";
    }

    public final class DateConstants {
        public static final String DEFAULT_EXPIRY_DATE = "31-12-9999";
    }

   /* public class FileLocation {

        @Autowired
        private static FileConfigs fileConfigs;

        public static final String fileName = fileConfigs.getFileName();
        public static final String input = StringUtils.join(
                fileConfigs.getInputFolder(), CommonConstants.SLASH, fileName);

        //  private FileConfigs fileConfigs = new FileConfigs();


    }*/
}
