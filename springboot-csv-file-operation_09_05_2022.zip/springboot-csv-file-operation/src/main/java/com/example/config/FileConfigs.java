package com.example.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;


@Getter
@Setter
@Configuration
@ConfigurationProperties
@EnableConfigurationProperties
@Component
public class FileConfigs {

    @Value("${fileConfiguration.inputFolder}")
    private String inputFolder;

    @Value("${fileConfiguration.successFolder}")
    private String successFolder;

    @Value("${fileConfiguration.errorFolder}")
    private String errorFolder;

    @Value("${fileConfiguration.fileName}")
    private String fileName;

}
