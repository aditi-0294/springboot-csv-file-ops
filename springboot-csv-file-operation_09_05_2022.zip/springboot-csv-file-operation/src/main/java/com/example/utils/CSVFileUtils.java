package com.example.utils;

import com.example.constants.IConstants;
import com.example.dto.ItemDto;
import com.opencsv.*;
import com.opencsv.bean.*;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;
import com.opencsv.exceptions.CsvValidationException;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.io.*;
import java.util.*;

@Component
public class CSVFileUtils {

    private static final Logger logger = LoggerFactory.getLogger(CSVFileUtils.class);

    Reader fr = null;
    Writer fw = null;

    CSVReader cr = null;
    CSVWriter cw = null;

    //getHeaderColumnsList
    public Map<String, Object> getHeaderColumnsList(String inputLocation, String fileName) {
        logger.info("START :::: retrieve file header column list as key-value pair :::: {}", logger.getName());

        Map<String, Object> fileContents = new HashMap<>();

        try {
            fr = new FileReader(fileName);
            cr = new CSVReader(fr);

            // read file header as Aarray as CSV reader takes input as Aarray
            String headerData[] = cr.readNext();

            // Convert it into list
            List<String> fileHeaderList = Arrays.asList(headerData);
            fileContents.put("headerData", fileHeaderList);

        } catch (FileNotFoundException e) {
            logger.error(IConstants.ExceptionConstants.FILE_NOT_FOUND, fileName);
            e.printStackTrace();
        } catch (CsvValidationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        logger.info("END :::: retrieve file header column list as key-value pair :::: {}", logger.getName());
        return  fileContents;
    }


    // to check if file is .csv
    public String getFileExtension(String fileName) {
        return fileName.substring(fileName.lastIndexOf(".")+1);
    }

    // to check for empty file
    public void getFileContents(String fileName) {
        try {
            fr = new FileReader(fileName);

            // check if file is empty
            if(fr.read() == -1) {
                logger.info("file is empty, exiting the system");
                System.exit(1);
            }
            else {
                logger.info("file contains data...");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        /*finally {
            if(fr != null) {
                log.info("closing stream");
                try {
                    fr.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }*/

    }

    // read file headers
    public List<String> extractHeader(String filePath) {
        logger.info("START :::: checking file {} for header contents", filePath);

        // read header
        try {
            fr = new FileReader(filePath);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        cr = new CSVReader(fr);

        String headerData[] = new String[0];

        try {
            try {
                headerData = cr.readNext();
                if(headerData.length == 0) {

                }
            } catch (CsvValidationException e) {
                e.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        List<String> fileHeader = Arrays.asList(headerData);

        logger.info("Header Contents :::: {}", fileHeader);
        logger.info("END :::: checking file {} for header contents", filePath);

        return fileHeader;
    }

    // read file
    public List<ItemDto> getItemList(String inputPath) {
        logger.debug("START ::::: Reading file contents");

        try {
            fr = new FileReader(inputPath);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        List<ItemDto> itemDtoList = new ArrayList<>();
        List<ItemDto> itemList = new ArrayList<>();

        CsvToBean<ItemDto> csvReader = new CsvToBeanBuilder(fr)
                .withType(ItemDto.class)
                .withSeparator(IConstants.CommonConstants.CSV_DELIMITER)
                .withIgnoreLeadingWhiteSpace(true)
                .withIgnoreEmptyLine(true)
                .withSkipLines(1)
                .build()
                ;

        itemDtoList = csvReader.parse();

        for(ItemDto itemDto: itemDtoList) {
         ItemDto dto = null;
            dto = populateRecords(itemDto);
            itemList.add(dto);
          //  itemList.add(populateRecords(itemDto));
        }

        logger.debug("itemDtoList :::: {}", itemDtoList.toString());
        logger.debug("END ::::: Reading file contents");

        //return itemDtoList;
        return itemList;

    }

    // populate records from pojo class
    public ItemDto populateRecords(ItemDto itemDto) {

        ItemDto itemDtoValue = new ItemDto();

        //item_id, item_name, item_description; item_type; item_price; item_manufactured_date;
        // item_expiry_date; item_qty;

        itemDtoValue.setItem_id(itemDto.getItem_id());
        itemDtoValue.setItem_name(itemDto.getItem_name());
        itemDtoValue.setItem_description(itemDto.getItem_description());
        itemDtoValue.setItem_type(itemDto.getItem_type());
        itemDtoValue.setItem_manufactured_date(DateUtil.setDateTime(itemDto.getItem_manufactured_date()));
        itemDtoValue.setItem_price(itemDto.getItem_price());
        itemDtoValue.setItem_expiry_date(itemDto.getItem_expiry_date());
        itemDtoValue.setItem_qty(itemDto.getItem_qty());


        return itemDtoValue;
    }

    // write file
    public void writeFile(String inputPath, String outputPath) {
        logger.debug("START :::: file read-write operations...");

        //createCsvFileHeader(inputPath, outputPath);

        String headerArray[] = extractHeader(inputPath).toArray(new String[0]);
        String delimiter = ",";
        //List<String> headerList = Arrays.asList(headerArray);

        String fileHeader = StringUtils.join(headerArray,delimiter);

        try {
            fw = new PrintWriter(outputPath);
            cw = new CSVWriter(fw, IConstants.CommonConstants.CSV_DELIMITER, CSVWriter.NO_QUOTE_CHARACTER,CSVWriter.NO_ESCAPE_CHARACTER, IConstants.CommonConstants.NEW_LINE);

        } catch (IOException e) {
            e.printStackTrace();
        }

        StatefulBeanToCsv sbc = null;
        sbc = new StatefulBeanToCsvBuilder(cw)
               // .withMappingStrategy(headerArray)
                .withSeparator(IConstants.CommonConstants.CSV_DELIMITER)
                .withLineEnd(IConstants.CommonConstants.NEW_LINE)
                .build();

        List<ItemDto> itemDtoList = getItemList(inputPath);

        //cw = new CSVWriter(fw, IConstants.CommonConstants.CSV_DELIMITER, CSVWriter.NO_QUOTE_CHARACTER,CSVWriter.NO_ESCAPE_CHARACTER, IConstants.CommonConstants.NEW_LINE);

        try {
           fw.write(fileHeader);
           fw.write(IConstants.CommonConstants.NEW_LINE);
           fw.flush();
            sbc.write(itemDtoList);
            cw.close();
            fw.close();
        } catch (CsvDataTypeMismatchException e) {
            e.printStackTrace();
        } catch (CsvRequiredFieldEmptyException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        logger.debug("END :::: file read-write operations...");
    }

    // create csv file -- line-by-line data
    public List<String> createCsvFileHeader(String infilePath, String outfilePath) {
        logger.info("START :::: constructing csv file {} with header contents", outfilePath);

        String headerArray[] = extractHeader(infilePath).toArray(new String[0]);
        logger.debug("Header contents as array :::: {}", headerArray);

        try {
            fw = new FileWriter(outfilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }

        cw = new CSVWriter(fw,
                IConstants.CommonConstants.CSV_DELIMITER,
                CSVWriter.NO_QUOTE_CHARACTER,
                CSVWriter.NO_ESCAPE_CHARACTER,
                IConstants.CommonConstants.NEW_LINE);

        try {
            cw.writeNext(headerArray);
            cw.flush();
            cw.close();
            fw.close();
            logger.debug("file written");
        }
        catch(Exception ex) {
            logger.debug("exception occurred");
            ex.printStackTrace();
        }


        logger.info("END :::: constructing csv file {} with header contents", outfilePath);

        return Arrays.asList(headerArray);
    }

}
