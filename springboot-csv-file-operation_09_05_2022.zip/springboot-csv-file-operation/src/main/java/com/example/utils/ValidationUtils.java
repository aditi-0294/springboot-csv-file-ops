package com.example.utils;

import com.example.constants.IConstants;
import com.example.dto.ItemDto;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.List;

@Component
public class ValidationUtils {

    private static final Logger logger = LoggerFactory.getLogger(ValidationUtils.class);

    /*@Autowired
    private CSVFileUtils csvFileUtils;*/

    @Autowired
    private CSVFileUtils csvFileUtils;

    Boolean flag = true;

    // check file extension
    public boolean checkFileExtension(String fileName) {
        logger.debug("START :::: checking file extension ...");
        String extension = csvFileUtils.getFileExtension(fileName);

        if(!IConstants.CommonConstants.CSV_EXTENSION.equals(extension)) {
            logger.error(IConstants.ExceptionConstants.FILE_EXTENSION_FORMAT_EXCEPTION);
            flag = false;
        }
        else {
            logger.debug("Accepting file-format for file ::: {}", fileName);
            flag = true;
        }

        logger.debug("END :::: checking file extension ...");

       return flag;
    }

    // check for empty file
    public boolean checkFileContents(String fileName) {
        logger.debug("START :::: checking for empty file ...");

        csvFileUtils.getFileContents(fileName);

        logger.debug("END :::: checking for empty file ...");
        return flag;
    }

    /*// file operations
    public void validateRecords(String inputPath) {
       logger.debug("START :::: validating records");

       ItemDto itemDto = new ItemDto();
       List<ItemDto> itemDtoList = csvFileUtils.getItemList(inputPath);
     //  List<String> itemDto1 = csvFileUtils.populateRecords(itemDto);


        if(itemDto.getItem_qty() == 0) {
            moveRecordToErrorFolder(String outputFilePath);
        }
        logger.debug("END :::: validating records");
    }*/

}
