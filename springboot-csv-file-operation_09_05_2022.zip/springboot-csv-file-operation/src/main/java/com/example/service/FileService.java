package com.example.service;

import com.example.config.FileConfigs;
import com.example.utils.CSVFileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.Map;

@Component
public class FileService {

    @Autowired
    private FileConfigs fc;

    @Autowired
    private CSVFileUtils csvFileUtils;

    String fileName = fc.getFileName();
    String inputLocation = fc.getInputFolder();
    String successLocation = fc.getSuccessFolder();
    String errorLocation = fc.getErrorFolder();

    private static final Logger logger = LoggerFactory.getLogger(FileService.class);

    public void initiateTask() {
        logger.info("START :::: initiate task :::: {}", logger.getName());
        logger.info("fileName ::: {}", fileName);
        startValidation(fileName);
        logger.info("END :::: initiate task :::: {}", logger.getName());
    }

    private void startValidation(String fileName) {
        logger.info("START :::: start validation process :::: {}", logger.getName());

        Map<String, Object> fileData = csvFileUtils.getHeaderColumnsList(inputLocation, fileName);
        logger.info("END :::: end validation process :::: {}", logger.getName());
    }


}
