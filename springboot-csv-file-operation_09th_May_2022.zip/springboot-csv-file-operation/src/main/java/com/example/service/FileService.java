package com.example.service;

import com.example.config.FileConfigs;
import com.example.constants.IConstants;
import com.example.processor.FileProcessor;
import com.example.utils.CSVFileUtils;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class FileService {

    private static Logger logger = LoggerFactory.getLogger(FileService.class);

    @Autowired
    private FileConfigs fc;

    Writer fw = null;
    CSVWriter cw = null;

    // move file to error or success folder
    public void moveFileToErrorFolder(String source, String destination, String sfileName, String dfileName, String errorMsg) {

        logger.info("START ::: copying file [{}] to Error folder [{}] ::::: {}", sfileName, dfileName, logger.getName());

        String Psource = StringUtils.join(source,sfileName);
        String Pdest = StringUtils.join(destination, dfileName);

        Path sourcePath = Paths.get(Psource);
        Path destPath = Paths.get(Pdest);

        try {
            Files.copy(sourcePath, destPath, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            logger.error(IConstants.ExceptionConstants.FILE_COPY_EXCEPTION, sfileName);
            e.printStackTrace();
        }

        logger.info("END ::: file copied as [{}] successfully at location [{}] ::::: {}", dfileName, destination, logger.getName());

        // after successful file move, append error to file
        appendError(dfileName, destination, errorMsg);

        // after successfully appending error message, delete file from source folder
        deleteFileFromSourceLocation(sfileName, source);

    }

    // log error
    private void appendError(String fileName, String dLocation, String errorMessage) {

        logger.info("START ::: appending error message to file [{}] :::::: {}", fileName, logger.getName());

        String errorLoc = StringUtils.join(dLocation, IConstants.CommonConstants.SLASH, fileName);

        try {
            fw = new PrintWriter(errorLoc);
            fw.write(errorMessage);
            fw.flush();

            cw = new CSVWriter(fw, IConstants.CommonConstants.CSV_DELIMITER, CSVWriter.NO_QUOTE_CHARACTER,CSVWriter.NO_ESCAPE_CHARACTER, IConstants.CommonConstants.NEW_LINE);
            cw.flush();

            cw.close();
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        logger.info("END ::: error message successfully appended to file [{}] :::::: {}", fileName, logger.getName());
    }

    // remove file from soure location
    private void deleteFileFromSourceLocation(String fileName, String slocation) {
        logger.info("START :::: deleting file [{}] from source location [{}] ::::: {} ", fileName, slocation, logger.getName());

        String filePath = StringUtils.join(slocation, IConstants.CommonConstants.SLASH, fileName);

        try {
            Files.deleteIfExists(Paths.get(filePath));
        } catch (IOException e) {
            logger.error("file [{}] does not exist at given path [{}]", fileName, slocation);
            e.printStackTrace();
        }

        logger.info("END :::: file [{}] deleted successfully from source location [{}] ::::: {} ", fileName, slocation, logger.getName());
    }

}
