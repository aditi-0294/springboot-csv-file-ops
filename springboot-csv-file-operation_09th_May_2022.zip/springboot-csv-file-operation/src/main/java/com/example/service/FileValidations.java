/*
package com.example.service;

import com.example.config.FileConfigs;
import com.example.constants.IConstants;
import com.example.dto.ItemDto;
import com.example.utils.CSVFileUtils;
import com.example.utils.ValidationUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class FileValidations {

    private  static final Logger logger = LoggerFactory.getLogger(FileValidations.class);

    @Autowired
    private FileConfigs fileConfigs;

    @Autowired
    private CSVFileUtils fileUtils;

    */
/*@Autowired
    private CSVFileUtils1 fileUtils;*//*


    @Autowired
    private ValidationUtils validationUtils;

    public void display() {

        String inputPath = StringUtils.join(fileConfigs.getInputFolder(),IConstants.CommonConstants.SLASH,
                fileConfigs.getFileName());

        String successPath = StringUtils.join(fileConfigs.getSuccessFolder(),IConstants.CommonConstants.SLASH,
                fileConfigs.getFileName());

        String errorPath = StringUtils.join(fileConfigs.getErrorFolder(),IConstants.CommonConstants.SLASH,
                fileConfigs.getFileName());

        logger.info("Hi ... I am in File Validation -- display()");
        logger.info("file in test ::: {}", fileConfigs.getFileName());

       if(validationUtils.checkFileExtension(fileConfigs.getFileName())) {
           if(validationUtils.checkFileContents(inputPath)) {
               fileUtils.createCsvFileHeader(inputPath,successPath);
               fileUtils.writeFile(inputPath,successPath);
           }


        }
        else {
           // moveFileToError(inputPath, errorPath);
            logger.info("Exiting the system ...");
            System.exit(1);
        }

    }
}
*/
