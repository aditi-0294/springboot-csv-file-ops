package com.example.service;

import com.example.config.FileConfigs;
import com.example.constants.IConstants;
import com.example.utils.CSVFileUtils;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ValidationService {
    private static final Logger logger = LoggerFactory.getLogger(ValidationService.class);

    @Autowired
    private FileConfigs fc;

    @Autowired
    private FileService fs;

    Reader fr = null;
    Writer fw = null;

    CSVReader cr = null;
    CSVWriter cw = null;

    // check for .csv file extension
    public void checkFileExtension(String sfileName) {
        logger.info("START :::: checking file extension :::: {}", logger.getName());

        sfileName = fc.getFileName();
        String fileExt = CSVFileUtils.getFileExtension(sfileName);

        if(!IConstants.CommonConstants.CSV_EXTENSION.equals(fileExt)) {
            logger.error("file [{}] is in incorrect format; moving to error folder", sfileName);

            String source = StringUtils.join(fc.getInputFolder(), IConstants.CommonConstants.SLASH);
            String destination = StringUtils.join(fc.getErrorFolder(), IConstants.CommonConstants.SLASH);
            String dfileName = CSVFileUtils.errorFileName(sfileName);
            String errorMessage = "file extension is incorrect; hence moved to error folder";

            fs.moveFileToErrorFolder(source, destination, sfileName, dfileName, errorMessage);

            logger.error("file [{}] successfully moved to error folder {}", sfileName, destination);

            System.exit(1);
        }
        logger.info("END :::: checking file extension :::: {}", logger.getName());
    }

    //getHeaderColumnsList
    public Map<String, Object> getHeaderColumnsList(String slocation, String sfileName) {
        logger.info("START :::: retrieve file header column list as key-value pair :::: {}", logger.getName());

        sfileName = fc.getFileName();
        slocation = StringUtils.join(fc.getInputFolder(), IConstants.CommonConstants.SLASH);

        String filePath = StringUtils.join(slocation, sfileName);

        Map<String, Object> fileContents = new HashMap<>();

        try {
            fr = new FileReader(filePath);
            if(fr.read() == -1) {
                logger.error("file [{}] is empty, so closing the file and moving it to error folder...");
                fr.close();
                String dlocation = StringUtils.join(fc.getErrorFolder(), IConstants.CommonConstants.SLASH);
                String dfilename = CSVFileUtils.errorFileName(sfileName);
                String errorMsg = "file is empty; hence moved to Error location";
                fs.moveFileToErrorFolder(slocation, dlocation, sfileName, dfilename, errorMsg);
                logger.error("file moved to error folder... exiting the system");
                System.exit(1);
            }
            cr = new CSVReader(fr);

            // read file header as Aarray as CSV reader takes input as Aarray
            String headerData[] = cr.readNext();

            // Convert it into list
            List<String> fileHeaderList = Arrays.asList(headerData);

            fileContents.put("headerData", fileHeaderList);

            logger.info("file contents data ::: {}", fileContents.toString());

        } catch (FileNotFoundException e) {
            logger.error(IConstants.ExceptionConstants.FILE_NOT_FOUND, sfileName, sfileName);
            e.printStackTrace();
        } catch (CsvValidationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        logger.info("END :::: retrieve file header column list as key-value pair :::: {}", logger.getName());
        return  fileContents;
    }
}
