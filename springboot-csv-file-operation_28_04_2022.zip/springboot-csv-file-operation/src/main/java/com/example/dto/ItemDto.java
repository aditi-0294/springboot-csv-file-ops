package com.example.dto;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.util.Date;

@Getter
@Setter
public class ItemDto {

    @NotNull
    private int item_id;

    @NotNull
    private String item_name;

    @NotNull
    private String item_description;

    @NotNull
    private String item_type;

    @NotNull
    private double item_price;

    @NotNull
    private Date item_manufactured_date;

    private Date item_expiry_date;

    @NotNull
    private int item_qty;
}
