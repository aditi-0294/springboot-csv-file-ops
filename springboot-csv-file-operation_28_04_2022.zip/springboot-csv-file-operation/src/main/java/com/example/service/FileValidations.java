package com.example.service;

import com.example.config.FileConfigs;
import com.example.constants.IConstants;
import com.example.utils.CSVFileUtils;
import com.example.utils.ValidationUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Slf4j
@Repository
public class FileValidations {

    private  static final Logger logger = LoggerFactory.getLogger(FileValidations.class);

    @Autowired
    private FileConfigs fileConfigs;

    @Autowired
    private CSVFileUtils fileUtils;

    @Autowired
    private ValidationUtils validationUtils;


    public void display() {

        String inputPath = StringUtils.join(fileConfigs.getInputFolder(),IConstants.CommonConstants.SLASH,
                fileConfigs.getFileName());

        String outputPath = StringUtils.join(fileConfigs.getSuccessFolder(),IConstants.CommonConstants.SLASH,
                fileConfigs.getFileName());

        log.info("Hi ... I am in File Validation -- display()");
        log.info("file in test ::: {}", fileConfigs.getFileName());

        if(validationUtils.checkFileExtension(fileConfigs.getFileName())) {
            fileUtils.extractHeader(inputPath);
            fileUtils.createCsvFileHeader(inputPath,outputPath);

            //fileUtils.cleanUp();
        }




    }
}
