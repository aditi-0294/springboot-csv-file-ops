package com.example.utils;

import com.example.config.FileConfigs;
import com.example.constants.IConstants;
import com.example.dto.ItemDto;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Slf4j
@Repository
public class ValidationUtils {

    private static final Logger logger = LoggerFactory.getLogger(ValidationUtils.class);

    @Autowired
    private CSVFileUtils csvFileUtils;

    @Autowired
    private ItemDto itemDto;

    Boolean flag = true;

    // check file extension
    public boolean checkFileExtension(String fileName) {
        log.info("START :::: checking file extension ...");
        String extension = csvFileUtils.getFileExtension(fileName);

        if(!IConstants.CommonConstants.CSV_EXTENSION.equals(extension)) {
            logger.error(IConstants.ExceptionConstants.FILE_EXTENSION_FORMAT_EXCEPTION);
            flag = false;
        }
        else {
            log.info("Accepting file-format for file ::: {}", fileName);
            flag = true;
        }

        log.info("END :::: checking file extension ...");

       return flag;
    }

    // check if item qty >= 0
    public void csvBodyValidations(List<String> itemList, StringBuilder builder) {
        logger.debug("START :::: checking csv file for validations");


        for(String str: itemList) {

            if(str.equals("")) {
                logger.error("no data to copy");
            }

            if(str.)
        }

        logger.debug("END :::: checking csv file for validations");
    }





}
