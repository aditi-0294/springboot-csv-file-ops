package com.example.utils;

import com.example.constants.IConstants;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.io.*;
import java.lang.reflect.Array;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Slf4j
@Repository
public class CSVFileUtils {

    FileReader fr = null;
    FileWriter fw = null;

    CSVReader cr = null;
    CSVWriter cw = null;

    // to check if file is .csv
    public String getFileExtension(String fileName) {
        return fileName.substring(fileName.lastIndexOf(".")+1);
    }

    // extract headers from CSV file







/*    // open csv file as input stream
    public InputStream readFileAsInputStream(String path) {
        InputStream is = null;

        if(!path.equals("")) {
            try {
                is = new FileInputStream(this.getClass().getClassLoader().getResource(path).getFile());
            } catch (FileNotFoundException fnfe) {
                log.error(IConstants.ExceptionConstants.FILE_NOT_FOUND);
                fnfe.printStackTrace();
            }
        }

        return is;
    }*/

    /*// open and read csv file
    public String readFileAsString(String path) {
        if(!path.equals("")) {
            try{
                return new String(Files.readAllBytes(Paths.get(path)));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return null;
    }*/

    //

    // read file headers and file contents
    public List<String> extractHeader(String filePath) {
        log.info("START :::: checking file {} for header contents", filePath);

        // read header
        try {
            fr = new FileReader(filePath);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        cr = new CSVReader(fr);

        String headerData[] = new String[0];
        try {
            headerData = cr.readNext();
        } catch (IOException e) {
            e.printStackTrace();
        }

        List<String> fileHeader = Arrays.asList(headerData);

        log.info("Header Contents :::: {}", fileHeader);
        log.info("END :::: checking file {} for header contents", filePath);

        return fileHeader;
    }

    // create csv file -- line-by-line data
    public List<String> createCsvFileHeader(String infilePath, String outfilePath) {
        log.info("START :::: constructing csv file {} with header contents", outfilePath);

        String headerArray[] = extractHeader(infilePath).toArray(new String[0]);
        log.debug("Header contents as array :::: {}", headerArray);

        try {
            fw = new FileWriter(outfilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }

        CSVWriter cw = null;
        cw = new CSVWriter(fw, IConstants.CommonConstants.CSV_DELIMITER, CSVWriter.NO_QUOTE_CHARACTER,CSVWriter.NO_ESCAPE_CHARACTER, IConstants.CommonConstants.NEW_LINE);

        //List<String[]> headerList = extractHeader(infilePath).toArray(new String[0]);
        // converting list to array


       // List<String[]> headerList = new ArrayList<>();
       // headerList.add(headerArray);


      //  List<String> headerList = new ArrayList<>();

        try {
            cw.writeNext(headerArray);
            cw.flush();
            log.debug("file written");
        }
        catch(Exception ex) {
            log.debug("exception occurred");
            ex.printStackTrace();
        }

        log.info("END :::: constructing csv file {} with header contents", outfilePath);

        return Arrays.asList(headerArray);
    }

    // create CSV data

    // close the streams
    @SneakyThrows
    public void cleanUp() {
        cr.close();
        cw.close();
        fr.close();
        fw.close();

    }
}
