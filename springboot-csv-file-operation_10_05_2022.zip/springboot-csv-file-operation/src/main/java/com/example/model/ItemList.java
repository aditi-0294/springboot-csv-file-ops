package com.example.model;

public class ItemList {

    private String mandatoryHeaders;
}
