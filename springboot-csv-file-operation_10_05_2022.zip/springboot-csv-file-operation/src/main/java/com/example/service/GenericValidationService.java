package com.example.service;

import com.example.config.FileConfigs;
import com.example.constants.IConstants;
import com.example.dto.ItemDto;
import com.example.utils.CSVFileUtils;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class GenericValidationService {
    private static final Logger logger = LoggerFactory.getLogger(GenericValidationService.class);

    @Autowired
    private FileConfigs fc;

    @Autowired
    private FileService fs;

    Reader fr = null;
    Writer fw = null;

    CSVReader cr = null;
    CSVWriter cw = null;

    // check for .csv file extension
    public void validateFileExtension(String sfileName) {
        logger.info("START :::: checking file extension :::: {}", logger.getName());

        sfileName = fc.getFileName();

        String fileExt = CSVFileUtils.getFileExtension(sfileName);

        if(!IConstants.CommonConstants.CSV_EXTENSION.equals(fileExt)) {
            logger.error("file [{}] is in incorrect format; moving to error folder", sfileName);

            String slocation = StringUtils.join(fc.getInputFolder(), IConstants.CommonConstants.SLASH);
            String edlocation = StringUtils.join(fc.getErrorFolder(), IConstants.CommonConstants.SLASH);
            String dfileName = CSVFileUtils.errorFileName(sfileName);
            String errorMessage = "file extension is incorrect; hence moved to error folder";

            fs.moveFileToErrorFolder(slocation, edlocation, sfileName, dfileName, errorMessage);
            logger.error("file [{}] successfully moved to error folder {}", sfileName, edlocation);

          //  fs.moveFileToErrorFolder(source, destination, sfileName, dfileName, errorMessage);
          //  logger.error("file [{}] successfully moved to error folder {}", sfileName, destination);

            System.exit(1);
        }
        logger.info("END :::: checking file extension :::: {}", logger.getName());
    }

    // check mandatory header column as list
    /*public void checkMandatoryColumns(List<String> fileHeaderList, ItemDto itemDto) {
        logger.info("START :::: check file headers with DTO ::::: {}", logger.getName());

        List<String> missingHeaderList = new ArrayList<>();
        String expHeaderList =
        logger.info("END :::: check file headers with DTO ::::: {}", logger.getName());
    }*/



}
