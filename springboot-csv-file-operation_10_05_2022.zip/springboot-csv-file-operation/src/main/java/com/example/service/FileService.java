package com.example.service;

import com.example.config.FileConfigs;
import com.example.constants.IConstants;
import com.example.dto.ItemDto;
import com.example.processor.FileProcessor;
import com.example.utils.CSVFileUtils;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.HeaderColumnNameMappingStrategy;
import com.opencsv.exceptions.CsvValidationException;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;

@Component
public class FileService {

    private static Logger logger = LoggerFactory.getLogger(FileService.class);

    @Autowired
    private FileConfigs fc;

    Reader fr = null;
    CSVReader cr = null;
    Writer fw = null;
    CSVWriter cw = null;

    // get csv file headers as list
    public Map<String, Object> getHeaderColumnsList(String slocation, String sfileName) {
        logger.info("START :::: retrieve file header column list as key-value pair :::: {}", logger.getName());

        sfileName = fc.getFileName();
        slocation = StringUtils.join(fc.getInputFolder(), IConstants.CommonConstants.SLASH);

        String filePath = StringUtils.join(slocation, sfileName);

        Map<String, Object> fileContents = new HashMap<>();

        try {
            fr = new FileReader(filePath);
            // if file is empty, move to error folder
            if(fr.read() == -1) {
                logger.error("file [{}] is empty, so closing the file and moving it to error folder...");
                fr.close();

                String edlocation = StringUtils.join(fc.getErrorFolder(), IConstants.CommonConstants.SLASH);

                String dfilename = CSVFileUtils.errorFileName(sfileName);
                String errorMsg = "file is empty; hence moved to Error location";

                moveFileToErrorFolder(slocation, edlocation, sfileName, dfilename, errorMsg);

                logger.error("file moved to error folder... exiting the system");
                System.exit(1);
            }
            cr = new CSVReader(fr);

            // read file header as Aarray as CSV reader takes input as Aarray
            String headerData[] = cr.readNext();

            // Convert it into list
            List<String> fileHeaderList = Arrays.asList(headerData);

            fileContents.put("headerData", fileHeaderList);

            logger.info("file contents data ::: {}", fileContents.toString());

            // close streams
            cr.close();
            fr.close();

        } catch (FileNotFoundException e) {
            logger.error(IConstants.ExceptionConstants.FILE_NOT_FOUND, sfileName, sfileName);
            e.printStackTrace();
        } catch (CsvValidationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        logger.info("END :::: retrieve file header column list as key-value pair :::: {}", logger.getName());
        return  fileContents;
    }

    // get CSV Contents as List
    public List<ItemDto> getFileContentsAsList() {
        logger.info("START :::: get csv file contents as list :::: {} ", logger.getName());

        String sfileName = fc.getFileName();
        String slocation = StringUtils.join(fc.getInputFolder(), IConstants.CommonConstants.SLASH);
        String filePath = StringUtils.join(slocation, sfileName);

        try {
            fr = new FileReader(filePath);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        cr = new CSVReader(fr);

        try {
            if(fr == null) {
                return Collections.emptyList();
            }

            HeaderColumnNameMappingStrategy<ItemDto> strategy = new HeaderColumnNameMappingStrategy<>();
            strategy.setType(ItemDto.class);

            CsvToBean<ItemDto> csvToBean = new CsvToBeanBuilder(cr)
                    .withMappingStrategy(strategy)
                    .withSeparator(IConstants.CommonConstants.CSV_DELIMITER)
                    .build();

            List<ItemDto> itemList = csvToBean.parse();

            logger.info("itemList = {}", itemList.toString());

            cr.close();
            fr.close();

            return itemList;

        } catch (Exception e) {
            logger.warn("unexpected exception caught ::: {}", e.getMessage());
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    // move file to error or success folder
    public void moveFileToErrorFolder(String source, String destination, String sfileName, String dfileName, String errorMsg) {

        logger.info("START ::: copying file [{}] to Error folder [{}] ::::: {}", sfileName, dfileName, logger.getName());

        String Psource = StringUtils.join(source,sfileName);
        String Pdest = StringUtils.join(destination, dfileName);

        Path sourcePath = Paths.get(Psource);
        Path destPath = Paths.get(Pdest);

        try {
            Files.copy(sourcePath, destPath, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            logger.error(IConstants.ExceptionConstants.FILE_COPY_EXCEPTION, sfileName);
            e.printStackTrace();
        }

        logger.info("END ::: file copied as [{}] successfully at location [{}] ::::: {}", dfileName, destination, logger.getName());

        // after successful file move, append error to file
        appendError(dfileName, destination, errorMsg);

        // after successfully appending error message, delete file from source folder
        deleteFileFromSourceLocation(sfileName, source);

    }

    // log error
    private void appendError(String fileName, String dLocation, String errorMessage) {

        logger.info("START ::: appending error message to file [{}] :::::: {}", fileName, logger.getName());

        String errorLoc = StringUtils.join(dLocation, IConstants.CommonConstants.SLASH, fileName);

        try {
            fw = new PrintWriter(errorLoc);
            fw.write(IConstants.CommonConstants.NEW_LINE);
            fw.write(errorMessage);
            fw.write(IConstants.CommonConstants.NEW_LINE);
            fw.flush();

            cw = new CSVWriter(fw, IConstants.CommonConstants.CSV_DELIMITER, CSVWriter.NO_QUOTE_CHARACTER,CSVWriter.NO_ESCAPE_CHARACTER, IConstants.CommonConstants.NEW_LINE);
            cw.flush();

            cw.close();
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        logger.info("END ::: error message successfully appended to file [{}] :::::: {}", fileName, logger.getName());
    }

    // remove file from soure location
    private void deleteFileFromSourceLocation(String fileName, String slocation) {
        logger.info("START :::: deleting file [{}] from source location [{}] ::::: {} ", fileName, slocation, logger.getName());

        String filePath = StringUtils.join(slocation, IConstants.CommonConstants.SLASH, fileName);

        try {
            Files.deleteIfExists(Paths.get(filePath));
        } catch (IOException e) {
            logger.error("file [{}] does not exist at given path [{}]", fileName, slocation);
            e.printStackTrace();
        }

        logger.info("END :::: file [{}] deleted successfully from source location [{}] ::::: {} ", fileName, slocation, logger.getName());
    }

    /*// write existing data and then append
    private boolean writeExistingData() {
        String sfilename = fc.getFileName();
        List<ItemDto> itmLst = getFileContentsAsList(sfilename);


    }*/

}
