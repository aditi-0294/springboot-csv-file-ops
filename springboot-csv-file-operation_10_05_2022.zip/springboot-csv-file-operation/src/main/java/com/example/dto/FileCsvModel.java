/*
package com.example.dto;

import com.opencsv.bean.CsvBindByName;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.util.Date;

@Getter
@Setter
public class FileCsvModel {

    @CsvBindByName(column = "item id")
    @NotNull
    private int item_id;

    @CsvBindByName(column = "item name")
    @NotNull
    private String item_name;

    @CsvBindByName(column = "item description")
    @NotNull
    private String item_description;

    @CsvBindByName(column = "item type")
    @NotNull
    private String item_type;

    @CsvBindByName(column = "item price")
    @NotNull
    private double item_price;

    @CsvBindByName(column = "item manufactured date")
    @NotNull
    private Date item_manufactured_date;

    @CsvBindByName(column = "item expiry date")
    private Date item_expiry_date;

    @CsvBindByName(column = "item qty")
    @NotNull
    private int item_qty;
}
*/
