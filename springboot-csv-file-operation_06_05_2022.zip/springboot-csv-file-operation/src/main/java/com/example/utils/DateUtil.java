package com.example.utils;

import com.example.constants.IConstants;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class DateUtil {

    private static final Logger logger = LoggerFactory.getLogger(DateUtil.class);

    public static String setDateTime(String dateTime) {
        logger.debug("START :::: converting string to local date time");

        SimpleDateFormat inputFormatter = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat outputFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        Date date = null;

        if(StringUtils.isNotEmpty(dateTime)) {
            try {
                date = inputFormatter.parse(dateTime);
                return outputFormatter.format(date);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        else {
        }

        logger.debug("END :::: converting string to local date time");
        return dateTime;
    }
}

    /*;*/
