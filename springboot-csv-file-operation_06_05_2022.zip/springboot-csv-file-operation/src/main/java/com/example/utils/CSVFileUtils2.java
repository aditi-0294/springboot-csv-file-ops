/*
package com.example.utils;

import com.example.constants.IConstants;
import com.example.dto.ItemDto;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.csv.CSVRecord;

@Repository
public class CSVFileUtils {

    private static final Logger logger = LoggerFactory.getLogger(CSVFileUtils.class);

    Reader fr = null;
    CSVParser csvParser = null;

    // defining csv format
    CSVFormat csvFormat = CSVFormat
            .DEFAULT.withDelimiter(IConstants.CommonConstants.CSV_DELIMITER)
           // .withRecordSeparator(IConstants.CommonConstants.NEW_LINE)
           .withFirstRecordAsHeader();

    // to check if file is .csv
    public String getFileExtension(String fileName) {
        return fileName.substring(fileName.lastIndexOf(".") + 1);
    }

    // to check for empty file
    public void getFileContents(String fileName) {
        try {
            //fr = new FileReader(fileName);

            fr = new StringReader(fileName);
            // check if file is empty
            if (fr.read() == -1) {
                logger.warn("file is empty, exiting the system");
                System.exit(1);
            } else {
                logger.info("file contains data... proceeding ....");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // extract headers from CSV file
    public List<String> extractHeaders(String inputFilePath) {

        logger.debug("START :::: extract headers");
        try {
            fr = new FileReader(inputFilePath);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // parsing the file header
        try {
            csvParser = new CSVParser(fr, csvFormat.withIgnoreHeaderCase().withTrim());
        } catch (IOException e) {
            e.printStackTrace();
        }

        List<String> fileHeader = new ArrayList<>(csvParser.getHeaderMap().keySet());
        logger.debug("Header list ::: {}", fileHeader);

        logger.debug("END :::: extract headers");

        return fileHeader;
    }

    // extract csv body
    public List<ItemDto> constructCSVBody(String filePath) {
        logger.debug("START :::: read csv body and get the bean values");

        fr = new StringReader(filePath);

        List<ItemDto> itemDtoList = new ArrayList<>();

        try {
           */
/* csvParser = new CSVParser(fr, csvFormat
                    .withIgnoreHeaderCase().withTrim()
                    .withHeader(String.valueOf(extractHeaders(filePath))));

            Iterable<CSVRecord> csvRecords = csvParser.getRecords();*//*


            Iterable<CSVRecord> csvRecords = csvFormat.parse(fr).getRecords();

            for(CSVRecord record : csvRecords) {
                logger.debug("Iterate over the loop to get single record ....");
                ItemDto itemDto = null;
                itemDto = populateValues(record);
                itemDtoList.add(itemDto);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }


        logger.debug("item list from csv :::: {}", itemDtoList);
        logger.debug("END :::: read csv body and get the bean values");
        return itemDtoList;
    }

    // populate each record -- csv-to-bean
    private ItemDto populateValues(CSVRecord record) {
        ItemDto itemData = new ItemDto();
        //item id,item name,item description,item type,item price,item manufactured date,item expiry date,item qty
        itemData.setItem_id(Integer.parseInt(record.get("item id")));
        itemData.setItem_name(record.get("item name"));
        itemData.setItem_description("item description");
        itemData.setItem_type("item type");
        itemData.setItem_price(Double.parseDouble(record.get("item price")));
        itemData.setItem_manufactured_date(record.get("item manufactured date"));
        itemData.setItem_expiry_date(record.get("item expiry date"));
        itemData.setItem_qty(Integer.parseInt(record.get("item qty")));

        return itemData;
    }
}

*/
/*
* private int item_id;

    private String item_name;

    private String item_description;

    private String item_type;

    private double item_price;

    private String item_manufactured_date;

    private String item_expiry_date;

    private int item_qty;
* */
